from django.db import models
#419
# Create your models here.
class CarDetails(models.Model):
    Name_of_the_car = models.CharField(max_length=10)
    Seat_Capacity = models.IntegerField()
    Rent_per_Day = models.IntegerField()
    Date_of_Service = models.DateTimeField()
