from django.db import models


# Create your models here.
class CarData(models.Model):
    Name_of_the_car = models.CharField(max_length=15)
    Seat_Capacity = models.IntegerField()
    Rent_per_Day = models.IntegerField()
    Date_of_service = models.DateField(blank=True,null=True,default='0000-00-00')