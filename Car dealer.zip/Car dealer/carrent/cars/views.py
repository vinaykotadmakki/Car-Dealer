from django.shortcuts import render

# Create your views here.
from .models import CarData

def car_detail_view(request):
    objs = CarData.objects.all()
    context={'data':objs}
    
    return render(request,"car/details.html", context)


def car_data_view(request, name):
    objs = CarData.objects.get(Name_of_the_car=name)
    context={'data':objs}
    return render(request,"car/data.html", context)

def home_view(request):
    objs = CarData.objects.all()
    context={'data':objs}
    return render(request,"car/details.html", context)

def order_view(request):
    if request.POST:
        print("coming here")
        custName = request.POST.get('customername')
        serviceDate= request.POST.get('dateandtime')
        carName = request.POST.get('carName')
        context={'custName':custName,'serviceDate':serviceDate,"carName":carName}
        # now validate to your heart's content
        return render(request, 'car/orderDetail.html', context)

