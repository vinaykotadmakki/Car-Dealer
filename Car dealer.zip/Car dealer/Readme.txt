Login Info
Username : vinay
password : vinay34892

First open Command promp
1 . Open the car dealer folder
2 . using command prompt go to the root folder which is "carrent"
3. Now run the server "python manage.py runserver"
4. Open any browser and run "http://127.0.0.1:8000/" this is the home page
5. You can also access homepage using "http://127.0.0.1:8000/home/"
6. Click on any vehicle name you want to rent.
7. On the next page type your name and date you wish to rent that vehicle.
8. Congrats you have successfully placed the order. 

Thank you